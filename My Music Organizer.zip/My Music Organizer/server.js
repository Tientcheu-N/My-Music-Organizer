const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const multer = require("multer");
const cors = require("cors");

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(express.static("public")); // Serve static files

// MongoDB URI
const MONGODB_URI =
  "mongodb+srv://zamiel01:Gokugoku01@cluster0.onp64.mongodb.net/myDatabase?retryWrites=true&w=majority";

// Connect to MongoDB
mongoose
  .connect(MONGODB_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Error connecting to MongoDB:", err));

// Song Schema
const songSchema = new mongoose.Schema({
  name: String,
  artist: String,
  description: String,
  genre: String,
  youtubeLink: String,
  image: String, // Stores image filename
});

const Song = mongoose.model("Song", songSchema);

// Multer setup for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "public/uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage });

// API Endpoints

// Add a new song
app.post("/submit", upload.single("image"), async (req, res) => {
  try {
    const { songName, artist, description, genre, youtubeLink } = req.body;
    const image = `/uploads/${req.file.filename}`;

    const newSong = new Song({
      name: songName,
      artist,
      description,
      genre,
      youtubeLink, // Already contains the video ID
      image,
    });

    await newSong.save();
    res.status(201).json({ message: "Song added successfully" });
  } catch (error) {
    console.error("Error adding song:", error);
    res.status(500).json({ message: "Failed to add song" });
  }
});

// Get all songs
app.get("/api/songs", async (req, res) => {
  try {
    const songs = await Song.find();
    res.status(200).json(songs);
  } catch (error) {
    console.error("Error fetching songs:", error);
    res.status(500).json({ message: "Failed to fetch songs" });
  }
});

// Get a specific song by ID
app.get("/api/songs/:id", async (req, res) => {
  try {
    const song = await Song.findById(req.params.id);
    if (!song) {
      return res.status(404).json({ message: "Song not found" });
    }
    res.status(200).json(song);
  } catch (error) {
    console.error("Error fetching song:", error);
    res.status(500).json({ message: "Failed to fetch song" });
  }
});

// Delete a song by ID
app.delete("/api/songs/:id", async (req, res) => {
  try {
    const song = await Song.findByIdAndDelete(req.params.id);
    if (!song) {
      return res.status(404).json({ message: "Song not found" });
    }
    res.status(200).json({ message: "Song deleted successfully" });
  } catch (error) {
    console.error("Error deleting song:", error);
    res.status(500).json({ message: "Failed to delete song" });
  }
});

// Start the server
const PORT = process.env.PORT || 3001; // Changed port to 3001
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});