// script.js

document.addEventListener("DOMContentLoaded", () => {
  const songsContainer = document.getElementById("songsContainer");
  const noMusicMessage = document.getElementById("noMusicMessage");
  const songModal = document.getElementById("songModal");
  const songIframe = document.getElementById("songIframe");
  const closeModal = document.getElementById("closeModal");
  const searchBar = document.getElementById("searchBar");

  // Fetch songs from the backend
  async function fetchSongs() {
      try {
          const response = await fetch('/api/songs'); // Fetch all songs
          const songs = await response.json();

          if (songs.length > 0) {
              noMusicMessage.style.display = "none";
              renderSongs(songs);
          } else {
              noMusicMessage.style.display = "block";
          }
      } catch (error) {
          console.error("Error fetching songs:", error);
      }
  }

  // Render songs dynamically
  function renderSongs(songs) {
      songsContainer.innerHTML = "";
      songs.forEach((song) => {
          const songCard = document.createElement("div");
          songCard.className = "song-card";
          songCard.draggable = true;

          songCard.innerHTML = `
              <img src="${song.image}" alt="${song.name}">
              <h3>${song.name}</h3>
              <p>${song.artist}</p>
              <button class="play-button" data-id="${song._id}">Play</button>
          `;

          // Play button event
          songCard.querySelector(".play-button").addEventListener("click", async (e) => {
              const id = e.target.getAttribute("data-id"); // Get the song ID
              const response = await fetch(`/api/songs/${id}`); // Fetch the song by ID
              const song = await response.json();
              const link = `https://www.youtube.com/embed/${song.youtubeLink}`; // Use the fetched song's YouTube link

              openModal(link);
          });

          // Drag and Drop
          songCard.addEventListener("dragstart", (e) => {
              e.dataTransfer.setData("text/plain", JSON.stringify(song));
          });

          songsContainer.appendChild(songCard);
      });
  }

  // Open modal with YouTube iframe
  function openModal(link) {
      songIframe.src = link;
      songModal.style.display = "block";
  }

  // Close modal
  closeModal.addEventListener("click", () => {
      songIframe.src = "";
      songModal.style.display = "none";
  });

  // Genre-based search
  searchBar.addEventListener("input", (e) => {
      const filter = e.target.value.toLowerCase();
      const songCards = document.querySelectorAll(".song-card");

      songCards.forEach((card) => {
          const genre = card.querySelector("p").innerText.toLowerCase();
          if (genre.includes(filter)) {
              card.style.display = "";
          } else {
              card.style.display = "none";
          }
      });
  });

  fetchSongs();
});